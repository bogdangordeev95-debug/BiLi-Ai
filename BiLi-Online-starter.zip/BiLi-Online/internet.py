from ddgs import DDGS

def search_internet(query, max_results=4):
    """Возвращает краткие фрагменты результатов поиска."""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        if not results:
            return "Поиск не нашёл подходящих результатов."
        lines = []
        for item in results:
            title = item.get("title", "Без заголовка")
            body = item.get("body", "")
            url = item.get("href", "")
            lines.append(f"Заголовок: {title}\nОписание: {body}\nСсылка: {url}")
        return "\n\n".join(lines)
    except Exception as exc:
        print(f"[SEARCH ERROR] {type(exc).__name__}: {exc}")
        return "Сейчас поиск в интернете недоступен."
