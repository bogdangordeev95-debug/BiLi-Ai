import time
import logging
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from config import VK_TOKEN, VK_GROUP_ID, validate_config
from memory import init_memory, clear_history
from ai import ask_bili

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

def _photo_url(message):
    """Берёт URL самого большого доступного размера фотографии из события VK."""
    attachments = message.get("attachments") or []
    for attachment in attachments:
        if attachment.get("type") != "photo":
            continue
        photo = attachment.get("photo") or {}
        sizes = photo.get("sizes") or []
        if sizes:
            best = max(sizes, key=lambda size: size.get("width", 0) * size.get("height", 0))
            return best.get("url")
    return None

def _extract_message(event):
    obj = event.object
    if isinstance(obj, dict):
        message = obj.get("message", obj)
    else:
        message = getattr(obj, "message", None)
        if message is None:
            return None
        if not isinstance(message, dict):
            message = {
                "peer_id": getattr(message, "peer_id", None),
                "from_id": getattr(message, "from_id", None),
                "text": getattr(message, "text", ""),
                "attachments": getattr(message, "attachments", [])
            }
    if not isinstance(message, dict):
        return None
    return message

def run_bot():
    validate_config()
    init_memory()

    session = vk_api.VkApi(token=VK_TOKEN)
    vk = session.get_api()
    group_id = int(VK_GROUP_ID)
    longpoll = VkBotLongPoll(session, group_id)

    logging.info("BiLi онлайн запущен. Ожидание сообщений сообщества...")

    while True:
        try:
            for event in longpoll.listen():
                if event.type != VkBotEventType.MESSAGE_NEW:
                    continue

                message = _extract_message(event)
                if not message:
                    continue

                text = (message.get("text") or "").strip()
                peer_id = message.get("peer_id")
                from_id = message.get("from_id")
                if not peer_id or not from_id or from_id < 0:
                    continue

                # Команда очистки памяти доступна только в личном диалоге.
                if text.lower() in ("/очистить память", "/clear") and peer_id == from_id:
                    clear_history(peer_id)
                    reply = "История нашей переписки очищена."
                else:
                    try:
                        image_url = _photo_url(message)
                        reply = ask_bili(
                            conversation_id=peer_id,
                            user_text=text,
                            image_url=image_url
                        )
                    except Exception as exc:
                        logging.exception("Ошибка обработки сообщения: %s", exc)
                        reply = (
                            "У меня временно возникла техническая проблема. "
                            "Попробуй отправить сообщение ещё раз чуть позже."
                        )

                # Отправка по peer_id работает и в личных, и в групповых беседах.
                vk.messages.send(
                    peer_id=peer_id,
                    message=reply[:4000],
                    random_id=0
                )
                logging.info("Ответ отправлен в беседу %s", peer_id)

        except Exception as exc:
            logging.exception("Сбой Long Poll: %s", exc)
            time.sleep(5)
