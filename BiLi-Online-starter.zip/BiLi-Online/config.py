import os
from dotenv import load_dotenv

load_dotenv()

VK_TOKEN = os.getenv("VK_TOKEN", "").strip()
VK_GROUP_ID = os.getenv("VK_GROUP_ID", "").strip()
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "").strip()

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
# Можно заменить на другую модель OpenRouter с поддержкой изображений.
AI_MODEL = os.getenv("AI_MODEL", "google/gemini-2.5-flash")

BOT_NAME = "BiLi онлайн"
DB_PATH = os.getenv("DB_PATH", "bili_memory.sqlite3")
MAX_HISTORY_MESSAGES = int(os.getenv("MAX_HISTORY_MESSAGES", "16"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "45"))

def validate_config():
    missing = []
    if not VK_TOKEN:
        missing.append("VK_TOKEN")
    if not VK_GROUP_ID:
        missing.append("VK_GROUP_ID")
    if not OPENROUTER_API_KEY:
        missing.append("OPENROUTER_API_KEY")
    if missing:
        raise RuntimeError(
            "Не заполнены переменные окружения: " + ", ".join(missing)
        )
