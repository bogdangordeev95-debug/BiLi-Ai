import sqlite3
from config import DB_PATH, MAX_HISTORY_MESSAGES

def _connect():
    connection = sqlite3.connect(DB_PATH, timeout=20)
    connection.execute("PRAGMA journal_mode=WAL")
    return connection

def init_memory():
    with _connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_conversation
            ON messages(conversation_id, id)
        """)

def add_message(conversation_id, role, content):
    if role not in ("user", "assistant"):
        raise ValueError("Недопустимая роль сообщения")
    with _connect() as db:
        db.execute(
            "INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)",
            (str(conversation_id), role, str(content)[:12000])
        )

def get_history(conversation_id):
    with _connect() as db:
        rows = db.execute(
            """SELECT role, content FROM messages
               WHERE conversation_id = ?
               ORDER BY id DESC LIMIT ?""",
            (str(conversation_id), MAX_HISTORY_MESSAGES)
        ).fetchall()
    rows.reverse()
    return [{"role": role, "content": content} for role, content in rows]

def clear_history(conversation_id):
    with _connect() as db:
        db.execute(
            "DELETE FROM messages WHERE conversation_id = ?",
            (str(conversation_id),)
        )
